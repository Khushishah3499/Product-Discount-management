package com.Product.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "ProductsDetails")
public class ProductModel {

    @Id
    @Column
    private Long productId;

    @Column
    private int productPrice;

    @Column
    private int quantity;

    @Column
    private String discountType;  

    @Column
    private double discountValue;

    @Column
    private double FinalDiscountedPrice;
    
    @Column
    private boolean seasonalDiscountActive;

    // Getters and Setters
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDiscountType() {
        return discountType;
    }

    public void setDiscountType(String discountType) {
        this.discountType = discountType;
    }

    public double getDiscountValue() {
        return discountValue;
    }

    public void setDiscountValue(double discountValue) {
        this.discountValue = discountValue;
    }

    public boolean isSeasonalDiscountActive() {
        return seasonalDiscountActive;
    }

    public void setSeasonalDiscountActive(boolean seasonalDiscountActive) {
        this.seasonalDiscountActive = seasonalDiscountActive;
    }

	public double getFinalDiscountedPrice() {
		return FinalDiscountedPrice;
	}

	public void setFinalDiscountedPrice(double finalDiscountedPrice) {
		FinalDiscountedPrice = finalDiscountedPrice;
	}
}
