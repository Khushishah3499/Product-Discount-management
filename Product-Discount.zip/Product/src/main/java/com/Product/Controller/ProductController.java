package com.Product.Controller;

import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Product.Model.ProductModel;
import com.Product.Service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {

	private ProductService productService;

	public ProductController(ProductService productService) {
		this.productService = productService;
	}

	@GetMapping("/{productId}")
	public Optional<ProductModel> getProductDetails(@PathVariable(value = "productId") long id) {
		return productService.getProductDetailsById(id);
	}

	@PostMapping("/discount")
	public String getProductDetails(@RequestBody ProductModel productModel) {
		return productService.insertProductDetails(productModel);
	}
}
