package com.Product.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.Product.Model.ProductModel;
import com.Product.Respository.ProductRepository;

@Service
public class ProductService {

	private final ProductRepository productRepository;

	public ProductService(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	public Optional<ProductModel> getProductDetailsById(long id) {
		 return productRepository.findById(id);
	}

	public String insertProductDetails(ProductModel productModel) {
		double finalPrice = productModel.getProductPrice();
		if (productModel.getQuantity() != 0) {
			if (productModel.getDiscountType().equalsIgnoreCase("percentage")
					|| productModel.getDiscountType().equalsIgnoreCase("flat")) {
				if (productModel.getDiscountType().equalsIgnoreCase("percentage")) {
					finalPrice = finalPrice - (finalPrice * productModel.getDiscountValue() / 100);
				} else if (productModel.getDiscountType().equalsIgnoreCase("flat")) {
					finalPrice = finalPrice - productModel.getDiscountValue();
				}
				if (finalPrice > 0) {
					productModel.setFinalDiscountedPrice(finalPrice);
					productRepository.save(productModel);
					return "Product Details added successfully, final with discounted price: " + finalPrice;
				} else {
					return "Details not saved as the Discounted price of product is getting less than 0 i.e. "
							+ finalPrice;
				}
			} else {
				return "Details not saved please enter Valid Discount Type";
			}
		} else {
			return "Details not added as its of stock";
		}
	}
}
